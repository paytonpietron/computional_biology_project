require(RCy3) || stop("unable to load RCy3")
BiocGenerics:::testPackage('RCy3')
