print ("Automatic execution of RCy3 unit tests disabled because they take too long for the build machine.")
#require("RCy3") || stop("unable to load RCy3 package")
#RCy3:::.test()
