### R code from vignette source 'BrowserViz.Rnw'

###################################################
### code chunk number 1: style
###################################################
BiocStyle::latex()


###################################################
### code chunk number 2: RJSON
###################################################
  library(jsonlite)
  msg <- toJSON(list(cmd="setBrowserWindowTitle", status="request", 
                     callback="handleResponse", payload="BrowserViz demo"))


