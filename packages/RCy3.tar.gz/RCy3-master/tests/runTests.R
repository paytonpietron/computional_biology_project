# tests disabled as the Bioconductor build system no longer supports interactive sessions
#require(RCy3) || stop("unable to load RCy3")
#BiocGenerics:::testPackage('RCy3')
