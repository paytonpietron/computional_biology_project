# disabled: the bioc build system no longer supports browser use.
# BiocGenerics:::testPackage("RCyjs")
